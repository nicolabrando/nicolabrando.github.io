def long(prices):

	from math import floor

	k = 6
	n_shares = 0
	cash_init = 100000
	inv_init = 0.5
	cash = cash_init

	v_account_value = []
	v_n = []
	v_cash = []
	v_gain_loss = []

	for i in range(len(prices)):

		price = prices[i]

		if i == 0:
			n_shares = round(cash*inv_init/price)
			cash -= n_shares*price
			v_n.append(n_shares)
			v_account_value.append(cash_init)
			v_cash.append(cash)
			continue

		gain_loss = cash + n_shares*price - inv_init

		if gain_loss > 0:
			buy_sell = floor(min(cash, gain_loss*k)/price)
			n_shares += buy_sell
			cash -= buy_sell*price
		else:
			buy_sell = floor(min(n_shares, gain_loss*k/price))
			n_shares -= buy_sell
			cash += buy_sell*price

		v_n.append(n_shares)
		v_account_value.append(cash + n_shares*price)
		v_cash.append(cash)
		v_gain_loss.append(gain_loss)

	return v_account_value[-1]/cash_init