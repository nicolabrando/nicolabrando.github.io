def bah(prices):

	return prices[-1]/prices[0]