def rsi(prices):

	from math import floor, inf
	import numpy as np

	k = 2
	n_shares = 0
	cash_init = 100000
	inv_init = 0.5
	cash = cash_init

	period = 14

	v_account_value = []

	v_n = []
	v_cash = []

	for i in range(len(prices)):

		price = prices[i]
		
		if i == 0:
			
			ut = 0
			dt = 0
			
			n_shares = floor(cash*inv_init/price) #
			cash -= n_shares*price

			v_n.append(n_shares)
			v_cash.append(cash)

			v_account_value.append(cash_init)


			continue
		
		#
		if i < period:
			v_n.append(n_shares)
			v_cash.append(cash)
			v_account_value.append(cash + (n_shares)*price)

			continue
		#
		if i == period:
			differences = list(np.array(prices[1:period+1]) -np.array(prices[0:period]))
			up = sum([change/14 for change in differences if change > 0])/period
			down = abs(sum([change/14 for change in differences if change < 0]))/period
			rsi = 100-(100/(1+up/down))
			
			v_n.append(n_shares)
			v_cash.append(cash)
			v_account_value.append(cash + (n_shares)*price)
			
			continue
			
		#
		delta = price - prices[i-1]
		
		if delta > 0:
			up = delta/period + up*(period-1)/period
			down *= ((period-1)/period)
		elif delta < 0:
			down = abs(delta)/period + up*(period-1)/period
			up *= ((period-1)/period)
		else:
			up *= ((period-1)/period)
			down *= ((period-1)/period)
		#
		
		rsi = 100-(100/(1+up/down))
		
		# buy
		if rsi > 70:
			to_sell = int(n_shares*(rsi - 70)/30)
			cash += to_sell * price
			n_shares -= to_sell
		
		# sell
		if rsi < 30:
			to_buy = int((cash*(30 - rsi)/30)/price)
			n_shares += to_buy
			cash -= to_buy * price
		#

		
		
		v_n.append(n_shares)
		v_cash.append(cash)
		v_account_value.append(cash + (n_shares)*price)
		
	

	return v_account_value[-1]/cash_init
