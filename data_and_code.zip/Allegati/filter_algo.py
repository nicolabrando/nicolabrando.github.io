#[["Alphabet","Amazon","Apple","Facebook","Microsoft"],["BP","Chevron","ExxonMobil","Shell","TotalSA"],["Ford","GM","Honda","Tesla","Toyota"],["BankOfAmerica","Citigroup","HSBC","JPMorganChase","WellsFargo"],["Boeing","GE","Honeywell","MMM","UnitedTechnologies"]]

from sls_for_filter import *
import numpy as np


def filter_algo(closing_prices):
	

	# filtering part

	returns = []

	for i in range(len(closing_prices)):
		returns.append(list(np.array(closing_prices[i][1:])/np.array(closing_prices[i][:-1])))
		returns[i].insert(0,1)

	average_returns = []

	for i in range(len(returns[0])):
		average_returns.append(sum([ret[i] for ret in returns])/len(returns))

	clos_filt_0 = [closing_prices[0],list(np.array(closing_prices[0])*np.array(average_returns))]
	clos_filt_1 = [closing_prices[1],list(np.array(closing_prices[1])*np.array(average_returns))]
	clos_filt_2 = [closing_prices[2],list(np.array(closing_prices[2])*np.array(average_returns))]
	clos_filt_3 = [closing_prices[3],list(np.array(closing_prices[3])*np.array(average_returns))]
	clos_filt_4 = [closing_prices[4],list(np.array(closing_prices[4])*np.array(average_returns))]


	# I now call a modified version of the SLS algorithm. It uses the filtered prices to calculate the gain/loss

	results = []

	results.append(sls_for_filter(clos_filt_0))
	results.append(sls_for_filter(clos_filt_1))
	results.append(sls_for_filter(clos_filt_2))
	results.append(sls_for_filter(clos_filt_3))
	results.append(sls_for_filter(clos_filt_4))

	return results
