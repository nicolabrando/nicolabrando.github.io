percentiles = [1.9379087753299092e-05, 4.720773078203066e-05, 9.39922935269018e-05, 0.0002149041075855512]
Ks = [10,6,2,1,0.5]
import numpy as np
from arch import arch_model

def fore(last_prices,p_param,q_param):
	
	log_diff = np.diff(np.log(last_prices))
	am = arch_model(log_diff,p=p_param,q=q_param)
	res = am.fit(update_freq = 0, show_warning=False)
	f = res.forecast()
	cond_var= f.residual_variance.iloc[-1]["h.1"]

	quintile = 0
	
	if cond_var > percentiles[0]:
		quintile = 1
	if cond_var > percentiles[1]:
		quintile = 2
	if cond_var > percentiles[2]:
		quintile = 3
	if cond_var > percentiles[3]:
		quintile = 4
	
	return Ks[quintile]
	

def sls_garch(prices,p,q):

	from math import floor, inf
	
	if p == 0:
		garch = False
	else:
		garch = True



	k = 6
	n_shares = 0
	n_shares_short = 0
	cash_init = 100000
	inv_init = 0.5
	cash = cash_init
	cash_short = 0
	short_limit = cash_init # * 2


	v_account_value = []

	v_n = []
	v_cash = []
	v_gain_loss_long = []

	v_n_short = []
	v_cash_short = []
	v_gain_loss_short = []

	for i in range(len(prices)):
		
		if i > 5 and garch:
			k = fore(prices[i-5:i],p,q)			

		price = prices[i]

		if i == 0:
			n_shares = floor(cash*inv_init/price) #
			cash -= n_shares*price

			n_shares_short = n_shares
			cash_short = n_shares*price

			v_n.append(n_shares)
			v_cash.append(cash)

			v_n_short.append(n_shares_short)
			v_cash_short.append(cash_short)

			v_account_value.append(cash_init)

			v_gain_loss_long.append(0) #
			v_gain_loss_short.append(0) #

			continue

		# --- Long Part ---

		gain_loss = cash + n_shares*price - cash_init

		if gain_loss > 0:
			buy_sell = floor(min(cash, gain_loss*k)/price)
			n_shares += buy_sell
			cash -= buy_sell*price
		else:
			buy_sell = floor(min(n_shares, -gain_loss*k/price)) ###
			n_shares -= buy_sell
			cash += buy_sell*price

		# --- Short Part ---

		gain_loss_short = cash_short - n_shares_short*price

		if gain_loss_short > 0:
			# Short more
			buy_sell = floor(min( max( 0, short_limit - n_shares_short*price), gain_loss_short*k)/price)
			n_shares_short += buy_sell
			cash_short += buy_sell*price
		else:
			# Buy back
			# 0 al posto di inf se non permetto indebitamento per short
			buy_sell = floor(min(max(inf,cash_short)/price,n_shares_short, abs(gain_loss_short)*k/price))
			n_shares_short -= buy_sell
			cash_short -= buy_sell*price

		# --- ---

		v_n.append(n_shares)
		v_cash.append(cash)
		v_gain_loss_long.append(gain_loss)

		v_n_short.append(n_shares_short)
		v_cash_short.append(cash_short)
		v_gain_loss_short.append(gain_loss_short)

		v_account_value.append(cash + cash_short + (n_shares - n_shares_short)*price)

	return v_account_value[-1]/cash_init

